package com.jxshr.bedrocknexus

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF171B25)
private val Accent = Color(0xFF6EE7F9)
private val Muted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            getSharedPreferences("nexus", MODE_PRIVATE).edit()
                .putString("last_import_uri", it.toString()).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var menuExpanded by remember { mutableStateOf(false) }
            var status by remember { mutableStateOf("Ready") }
            val minecraftInstalled = remember {
                try {
                    packageManager.getPackageInfo("com.mojang.minecraftpe", 0)
                    true
                } catch (_: Exception) { false }
            }
            val overlayAllowed = remember { mutableStateOf(Settings.canDrawOverlays(this)) }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    Column(
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(52.dp).background(Accent, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.SportsEsports, null, tint = Bg, modifier = Modifier.size(30.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Text("BEDROCK NEXUS", fontSize = 21.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text("MOBILE LAUNCHER • EARLY BUILD", fontSize = 10.sp, color = Accent, letterSpacing = 1.2.sp)
                            }
                            Icon(Icons.Default.Settings, "Settings", tint = Muted)
                        }

                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("YOUR GAME", color = Muted, fontSize = 12.sp, letterSpacing = 1.5.sp)
                                Text("Minecraft Bedrock", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (minecraftInstalled) Icons.Default.CheckCircle else Icons.Default.Warning, null,
                                        tint = if (minecraftInstalled) Accent else Color(0xFFFFC078))
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (minecraftInstalled) "Standard installation detected" else "Standard Minecraft package not detected",
                                        color = if (minecraftInstalled) Accent else Color(0xFFFFC078), fontSize = 13.sp)
                                }
                                Button(onClick = {
                                    val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                                    if (intent != null) {
                                        status = "Opening Minecraft…"
                                        startActivity(intent)
                                    } else status = "Could not open standard Minecraft package."
                                }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                                    Icon(Icons.Default.PlayArrow, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("LAUNCH MINECRAFT", fontWeight = FontWeight.Bold)
                                }
                                Text("Status: $status", color = Muted, fontSize = 12.sp)
                            }
                        }

                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("FLOATING UTILITY MENU", fontWeight = FontWeight.Bold, color = Accent)
                                Text("A movable button that can sit over other apps. It does not modify Minecraft memory or inject code.", color = Muted, fontSize = 13.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (overlayAllowed.value) Icons.Default.CheckCircle else Icons.Default.Security,
                                        null, tint = if (overlayAllowed.value) Accent else Color(0xFFFFC078))
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (overlayAllowed.value) "Overlay permission granted" else "Overlay permission required", fontSize = 13.sp)
                                }
                                Button(onClick = {
                                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                                        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:$packageName"))
                                        startActivity(intent)
                                        status = "Allow Bedrock Nexus to display over other apps, then return."
                                    } else {
                                        overlayAllowed.value = true
                                        startService(Intent(this@MainActivity, FloatingMenuService::class.java))
                                        status = "Floating utility menu started."
                                    }
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.Layers, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (overlayAllowed.value) "SHOW FLOATING MENU" else "GRANT OVERLAY PERMISSION")
                                }
                                OutlinedButton(onClick = {
                                    stopService(Intent(this@MainActivity, FloatingMenuService::class.java))
                                    status = "Floating utility menu stopped."
                                }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Default.Close, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("STOP FLOATING MENU")
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ToolCard("Add-ons & worlds", "Select a file", Icons.Default.FolderOpen, Modifier.weight(1f)) {
                                importPicker.launch(arrayOf("*/*"))
                                status = "File selected via Android picker; importing is not implemented yet."
                            }
                            ToolCard("Utility settings", if (menuExpanded) "Hide details" else "View details", Icons.Default.Tune, Modifier.weight(1f)) {
                                menuExpanded = !menuExpanded
                            }
                        }
                        if (menuExpanded) {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("CURRENT LIMITATIONS", fontWeight = FontWeight.Bold, color = Accent)
                                    Text("The overlay has launcher-side buttons only. It cannot read Minecraft FPS, change in-game coordinates, or apply cheats. Android and Minecraft version differences may affect overlay behavior.", color = Muted, fontSize = 13.sp)
                                }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("WORLD SAFETY", fontWeight = FontWeight.Bold)
                                Text("Make a separate backup of important worlds before updating Minecraft. World import/export will be a later milestone.", color = Muted, fontSize = 13.sp)
                            }
                        }
                        Text("Bedrock Nexus 0.2.0 • Independent community project • Not affiliated with Mojang", color = Muted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                     modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp), onClick = onClick) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(28.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}
