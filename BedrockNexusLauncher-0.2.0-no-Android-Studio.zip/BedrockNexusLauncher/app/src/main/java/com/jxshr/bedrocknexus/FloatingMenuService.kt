package com.jxshr.bedrocknexus

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

/**
 * A lightweight Android floating utility menu.
 * It is a separate overlay window, not an in-game mod injector.
 */
class FloatingMenuService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) return START_NOT_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 28
            y = 180
        }

        bubble = TextView(this).apply {
            text = "N"
            textSize = 20f
            setTextColor(Color.rgb(11, 13, 18))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(110, 231, 249), 100f)
            elevation = 12f
            setPadding(18, 12, 18, 12)
            contentDescription = "Bedrock Nexus floating menu. Drag to move, tap to open."
        }
        bubble?.setOnTouchListener(DragTouchListener())
        bubble?.setOnClickListener { togglePanel() }
        windowManager.addView(bubble, bubbleParams)
        return START_NOT_STICKY
    }

    private fun togglePanel() {
        if (panel != null) {
            removePanel()
            return
        }
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = rounded(Color.rgb(23, 27, 37), 24f)
            elevation = 16f
        }
        panel?.addView(TextView(this).apply {
            text = "NEXUS UTILITIES"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(110, 231, 249))
            setPadding(0, 0, 0, 10)
        })
        panel?.addView(TextView(this).apply {
            text = "Floating companion menu"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 10)
        })
        addAction("HUD NOTES") {
            showMessage("HUD tools are a future milestone. This overlay cannot read game HUD data yet.")
        }
        addAction("PERFORMANCE TIPS") {
            showMessage("For smoother play, lower render distance and close background apps in Minecraft settings.")
        }
        addAction("CLOSE PANEL") { removePanel() }
        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleParams.x
            y = bubbleParams.y + 70
        }
        windowManager.addView(panel, panelParams)
    }

    private fun addAction(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 11f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(42, 51, 66), 14f)
            isAllCaps = false
            setOnClickListener { action() }
        }
        panel?.addView(button, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 7 })
    }

    private fun showMessage(message: String) {
        // Keep the overlay self-contained; message appears in the panel.
        panel?.findViewWithTag<TextView>("status")?.let { panel?.removeView(it) }
        val status = TextView(this).apply {
            tag = "status"
            text = message
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(4, 8, 4, 8)
        }
        panel?.addView(status, 1)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun removePanel() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        panelParams = null
    }

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) moved = true
                    bubbleParams.x = startX + dx
                    bubbleParams.y = startY + dy
                    try { windowManager.updateViewLayout(bubble, bubbleParams) } catch (_: Exception) {}
                    panelParams?.let {
                        it.x = bubbleParams.x
                        it.y = bubbleParams.y + 70
                        try { windowManager.updateViewLayout(panel, it) } catch (_: Exception) {}
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) view.performClick()
                    return true
                }
            }
            return false
        }
    }
}
