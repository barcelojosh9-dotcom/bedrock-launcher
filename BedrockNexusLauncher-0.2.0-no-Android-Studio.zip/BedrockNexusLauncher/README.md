# Bedrock Nexus Launcher — 0.2.0 floating-menu milestone

Native Android/Kotlin starter. This project provides a separate floating utility overlay, not a Minecraft code injector.

## Added in 0.2.0
- Android overlay permission flow (`SYSTEM_ALERT_WINDOW`)
- Start/stop floating menu from the launcher
- Draggable floating `N` button
- Tap to open a small utility panel
- Buttons for basic performance tips and HUD-tool roadmap notes
- Standard package detection/launch for `com.mojang.minecraftpe`

## Important limits
- This does not bypass Minecraft licensing and does not support cracked-license bypasses.
- The overlay is a separate Android window. It does not inject into Minecraft, alter game memory, or read the game's FPS/HUD.
- Minecraft 1.26.50+ compatibility is not guaranteed for third-party or renamed APK packages. Standard package detection expects `com.mojang.minecraftpe`.
- Add-on/world file picker only selects a file; actual import/export is not implemented yet.
- Android may show a security prompt for “Display over other apps”. Enable it only for this app if you want the floating button.
- The overlay may be blocked or hidden by some secure/full-screen contexts and device-specific Android restrictions.

## Windows setup
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP to a normal folder such as `C:\Users\YourName\Projects\BedrockNexusLauncher`.
3. Android Studio → **Open** → select the extracted `BedrockNexusLauncher` directory.
4. Let Gradle sync. If asked for a JDK, use Android Studio's bundled JDK.
5. Use **Build → Build APK(s)**.
6. Copy the debug APK from `app\build\outputs\apk\debug\app-debug.apk` to your Android phone.
7. Install it. Open Bedrock Nexus → tap **Grant overlay permission** → enable “Allow display over other apps” → return to the app → tap **Show floating menu**.
8. Launch Minecraft from the app, or start Minecraft first and then show the overlay.

## Troubleshooting
- If Gradle sync fails, confirm Android Studio has Android SDK Platform 35 installed and internet access to download dependencies.
- If Android Studio says the Gradle JDK is missing, set it to the embedded JDK in Settings → Build, Execution, Deployment → Build Tools → Gradle.
- If the menu does not appear, verify overlay permission and stop/restart the service.
- The project source is provided; no compiled APK is bundled.

## Build without Android Studio (GitHub Actions)
This repository includes `.github/workflows/build-apk.yml`.

1. Sign in to GitHub and create a new repository.
2. Upload the extracted project files to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build Bedrock Nexus APK** and click **Run workflow**, or push to the `main` branch.
5. When the workflow completes successfully, open the run and download the `Bedrock-Nexus-debug-APK` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`.

This uses GitHub-hosted Linux runners to compile the project. You do not need Android Studio installed locally. Keep the repository private if you do not want the source code public. Do not upload signing keys or passwords to the repository.
